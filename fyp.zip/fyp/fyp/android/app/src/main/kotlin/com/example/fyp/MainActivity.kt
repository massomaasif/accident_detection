package com.example.fyp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
